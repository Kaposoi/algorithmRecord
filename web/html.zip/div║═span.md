# div和span

div和span标签没有语义，只是相当于一个盒子结组。

\<div>（大盒子

div一个人独占一行，div后面的会在div包裹的句子下面显示

\</div>



\<span>（小盒子

span不独占一行。

\</span>