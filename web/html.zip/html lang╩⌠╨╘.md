# html lang属性

lang是language缩写

表示语言

lang="en" 是英文

lang="zh-CN"是中文

只是一种提示，并不是说写了en就不能写中文

